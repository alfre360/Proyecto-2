package com.example;

import java.util.ArrayList;

public class GestionObras {
    
    private ArrayList<Obra> obras;

    public GestionObras() {
        this.obras = new ArrayList<>();
    }

    public ArrayList<Obra> getObras() {
        return obras;
    }

    public void setObras(ArrayList<Obra> obras) {
        this.obras = obras;
    }

    public Obra buscarObra(String titulo) {
        for (int i = 0; i < obras.size(); i++) {
            if (obras.get(i).getTitulo().equalsIgnoreCase(titulo)) {
                return obras.get(i);
            }
        }
        return null;
    }

    public boolean agregarObra(Obra obra) {
        Obra o = buscarObra(obra.getTitulo());
        if (o == null) {
            obras.add(obra);
            return true;
        }
        return false;
    }

    public boolean eliminarObra(String titulo) {
       Obra o = buscarObra(titulo);
        if (o != null) {
            obras.remove(o);
            return true;
        }
        return false;
    }

    public String listarObras() {
        String salida = "";
        for (int i = 0; i < obras.size(); i++) {
            salida += obras.get(i).toString() + "\n";
        }
        return salida;
    }
}
