package com.example;

import java.util.ArrayList;

public class ControlCliente {
    
    private ArrayList<Cliente> clientes;

    public ControlCliente() {
        this.clientes = new ArrayList<>();
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public Cliente buscarCliente(String nombre) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getNombre().equalsIgnoreCase(nombre)) {
                return clientes.get(i);
            }
        }
        return null;
    }

    public boolean agregarCliente(Cliente cliente) {
       Cliente c = buscarCliente(cliente.getNombre());
        if (c == null) {
            clientes.add(cliente);
            return true;
        }
        return false;
    }

    public boolean eliminarCliente(String nombre) {
        Cliente c = buscarCliente(nombre);
        if (c != null) {
            clientes.remove(c);
            return true;
        }
        return false;
    }

    public String listarClientes() {
        String salida = "";
        for (int i = 0; i < clientes.size(); i++) {
            salida += clientes.get(i).toString() + "\n";
        }
        return salida;
    }
}
