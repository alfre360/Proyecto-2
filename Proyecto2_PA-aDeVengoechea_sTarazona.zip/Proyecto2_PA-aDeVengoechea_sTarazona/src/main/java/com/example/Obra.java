package com.example;

public class Obra {
    private String titulo;
    private String tecnica;
    private int anio;
    private double precio;
    private Artista artista;

    public Obra(String titulo, String tecnica, int anio, double precio, Artista artista) {
        this.titulo = titulo;
        this.tecnica = tecnica;
        this.anio = anio;
        this.precio = precio;
        this.artista = artista;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    @Override
    public String toString() {
        return "Obra [titulo=" + titulo + ", tecnica=" + tecnica + ", anio=" + anio + ", precio=" + precio
                + ", artista=" + artista + "]";
    }

    
    
    

    

    
}
