package com.example;

import java.time.LocalDate;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class PantallaGaleria {
    private static ControlGaleria controlGaleria;
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        controlGaleria = new ControlGaleria();

        int opcion = 999;
        while(opcion!=0)
        {
            opcion = menu();
            switch(opcion)
            {
                case 1:
                    agregarArtista();
                    break;
                case 2:
                    listarArtistas();
                    break;
                case 3:
                    agregarObra();
                    break;
                case 4:
                    listarObras();
                    break;
                case 5:
                    agregarCliente();
                    break;
                case 6:
                    listarClientes();
                    break;
                case 7:
                    agregarCompra();
                    break;
                case 8:
                    listarCompras();
                    break;
                case 9:
                    eliminarArtista();
                    break;
                case 10:
                    eliminarObra();
                    break;
                case 11:
                    eliminarCliente();
                    break;
                case 12:
                    eliminarCompra();
                    break;
                
                case 0:
                    System.out.println("Hasta Luego");
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
    }

    public static int menu()
    {
        System.out.println("MENU GALERÍA");
        System.out.println("1. Agregar artista");
        System.out.println("2. Listar artistas");
        System.out.println("3. Agregar obra");
        System.out.println("4. Listar obras");
        System.out.println("5. Agregar cliente");
        System.out.println("6. Listar clientes");
        System.out.println("7. Registrar compra");
        System.out.println("8. Listar compras");
        System.out.println("9. Eliminar artista");
        System.out.println("10. Eliminar obra");
        System.out.println("11. Eliminar cliente");
        System.out.println("12. Eliminar compra");
        System.out.println("0. Salir");
        System.out.println("Ingrese una opcion");
        int opcion = sc.nextInt();
        sc.nextLine();
        return opcion;
    }

    public static void agregarArtista() {
        try {

            System.out.println("AGREGAR ARTISTA");

            // Solicitar datos
            System.out.println("Ingrese nombre del artista");
            String nombre = sc.nextLine();
            System.out.println("Ingrese el anio de nacimiento del artista");
            int anio = sc.nextInt();
            sc.nextLine();
            System.out.println("Ingrese el mes de nacimiento del artista");
            int mes = sc.nextInt();
            sc.nextLine();
            System.out.println("Ingrese el dia de nacimiento del artista");
            int dia = sc.nextInt();
            sc.nextLine();
            System.out.println("Ingrese la nacionalidad del artista");
            String nacionalidad = sc.nextLine();
            System.out.println("Ingrese la biografia del artista");
            String biografia = sc.nextLine();
            // Convertir fecha de nacimiento
            LocalDate fechaNacimiento = LocalDate.of(anio, mes, dia);

            // Crear objeto artista
            Artista artista = new Artista(nombre, fechaNacimiento, nacionalidad, biografia);
            boolean resultado = controlGaleria.agregarArtista(artista);

            if (resultado) {
                System.out.println("Artista agregado correctamente");
            } else {
                System.out.println("Artista con ese nombre ya existente");
            }

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }

    }

    public static void eliminarArtista()
    {
        try {
            System.out.println("ELIMINAR ARTISTA");
            listarArtistas();
            System.out.println("Ingrese el nombre del artista");
            String nombre = sc.nextLine();
            boolean resultado = controlGaleria.eliminarArtista(nombre);
            if (resultado) {
                System.out.println("Artista eliminado correctamente");
            } else {
                System.out.println("Artista no encontrado");
            }

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
    public static void agregarObra() {
        try {
            System.out.println("AGREGAR OBRA");
            System.out.println("Ingrese el titulo de la obra");
            String titulo = sc.nextLine();
            // Buscar si la obra ya existe
            Obra encontrado = controlGaleria.getGestionObras().buscarObra(titulo);
            if (encontrado != null) {
                throw new Exception("Obra ya existente");
            }

            System.out.println("Ingrese la tecnica de la obra");
            String tecnica = sc.nextLine();
            System.out.println("Ingrese el anio de la obra");
            int anio = sc.nextInt();
            sc.nextLine();
            System.out.println("Ingrese el precio de la obra");
            double precio = sc.nextDouble();
            sc.nextLine();

            listarArtistas();

            System.out.println("Ingrese el nombre del artista");
            String nombreArtista = sc.nextLine();

            // Buscar artista
            Artista artista = controlGaleria.buscarArtista(nombreArtista);
            if (artista == null) {
                throw new Exception("Artista no encontrado");
            }

            // Crear objeto obra
            Obra obra = new Obra(titulo, tecnica, anio, precio, artista);
            boolean resultado = controlGaleria.agregarObra(obra);
            if (resultado) {
                System.out.println("Obra agregada correctamente");
            } else {
                System.out.println("Obra no agregada");
            }

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void eliminarObra(){
        try {
            System.out.println("ELIMINAR OBRA");
            listarObras();
            System.out.println("Ingrese el titulo de la obra");
            String titulo = sc.nextLine();
            boolean resultado = controlGaleria.eliminarObra(titulo);
            if (resultado) {
                System.out.println("Obra eliminada correctamente");
            } else {
                System.out.println("Obra no encontrada");
            }
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
    public static void agregarCliente() {
        try {
            System.out.println("AGREGAR CLIENTE");
            System.out.println("Ingrese el nombre del cliente");
            String nombre = sc.nextLine();

            Cliente encontrado = controlGaleria.buscarCliente(nombre);
            if (encontrado != null) {
                throw new Exception("Cliente ya existente");
            }

            System.out.println("Ingrese la dirección del cliente");
            String direccion = sc.nextLine();

            System.out.println("Ingrese el email del cliente");
            String email = sc.nextLine();

            // Crear objeto cliente
            Cliente cliente = new Cliente(nombre, direccion, email);
            boolean resultado = controlGaleria.agregarCliente(cliente);
            if (resultado) {
                System.out.println("Cliente agregado correctamente");
            } else {
                System.out.println("Cliente no agregado");
            }

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void eliminarCliente(){
        try {
            System.out.println("ELIMINAR CLIENTE");
            listarClientes();
            System.out.println("Ingrese el nombre del cliente");
            String nombre = sc.nextLine();
            boolean resultado = controlGaleria.eliminarCliente(nombre);
            if (resultado) {
                System.out.println("Cliente eliminado correctamente");
            } else {
                System.out.println("Cliente no encontrado");
            }
            
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void agregarCompra()
    {
        try {
            System.out.println("AGREGAR COMPRA");

            listarClientes();

            System.out.println("Ingrese el nombre del cliente");
            String nombreCliente = sc.nextLine();
            // Buscar cliente
            Cliente cliente = controlGaleria.buscarCliente(nombreCliente);
            if(cliente == null)
            {
                throw new Exception("Cliente no encontrado");
            }

            listarObras();

            //Buscar obra
            System.out.println("Ingrese el titulo de la obra");
            String tituloObra = sc.nextLine();
            Obra obra = controlGaleria.buscarObra(tituloObra);
            if(obra == null)
            {
                throw new Exception("Obra no encontrada");
            }

            System.out.println("Ingrese el precio de la compra");
            double precio = sc.nextDouble();

            // Crear objeto compra
            Compra compra = new Compra(precio, cliente, obra);
            boolean resultado = controlGaleria.realizarCompra(compra);
            if(resultado)
            {
                System.out.println("Compra realizada correctamente");
            }
            else
            {
                System.out.println("Compra no realizada");
            }
            
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void eliminarCompra()
    {
        try {
            System.out.println("ELIMINAR COMPRA");
            listarCompras();
            System.out.println("Ingrese el nombre del cliente");
            String nombreCliente = sc.nextLine();
            System.out.println("Ingrese el titulo de la obra");
            String tituloObra = sc.nextLine();
            boolean resultado = controlGaleria.eliminarCompra(nombreCliente, tituloObra);
            if(resultado)
            {
                System.out.println("Compra eliminada correctamente");
            }
            else
            {
                System.out.println("Compra no encontrada");
            }
            
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
    public static void listarArtistas() {
        System.out.println("LISTAR ARTISTAS");
        System.out.println(controlGaleria.listarArtistas()); 
        System.out.println();
    }

    public static void listarObras() {
        System.out.println("LISTAR OBRAS");
        System.out.println(controlGaleria.listarObras());
        System.out.println();
    }

    public static void listarClientes() {
        System.out.println("LISTAR CLIENTES");
        System.out.println(controlGaleria.listarClientes());
        System.out.println();
    }

    public static void listarCompras() {
        System.out.println("LISTAR COMPRAS");
        System.out.println(controlGaleria.listarCompras());
    }
}
