package com.example;

import java.util.ArrayList;

public class ControlGaleria {
    
    private ArrayList<Compra> compras;
    private ArrayList<Artista> artistas;
    private ControlCliente controlCliente;
    private GestionObras gestionObras;

    public ControlGaleria() {
        this.compras = new ArrayList<>();
        this.artistas = new ArrayList<>();
        this.controlCliente = new ControlCliente();
        this.gestionObras = new GestionObras();
    }

    public ArrayList<Compra> getCompras() {
        return compras;
    }

    public void setCompras(ArrayList<Compra> compras) {
        this.compras = compras;
    }

    public ArrayList<Artista> getArtistas() {
        return artistas;
    }

    public void setArtistas(ArrayList<Artista> artistas) {
        this.artistas = artistas;
    }

    public ControlCliente getControlCliente() {
        return controlCliente;
    }

    public void setControlCliente(ControlCliente controlCliente) {
        this.controlCliente = controlCliente;
    }

    public GestionObras getGestionObras() {
        return gestionObras;
    }

    public void setGestionObras(GestionObras gestionObras) {
        this.gestionObras = gestionObras;
    }

    //---------------ARTISTAS-----------------

    public Artista buscarArtista(String nombre) {
        for (int i = 0; i < artistas.size(); i++) {
            if (artistas.get(i).getNombre().equalsIgnoreCase(nombre)) {
                return artistas.get(i);
            }
        }
        return null;
    }
    
    public boolean agregarArtista(Artista artista) {
        Artista art = buscarArtista(artista.getNombre());
        if (art == null) {
            artistas.add(artista);
            return true;
        }
        return false;
    }

    public boolean eliminarArtista(String nombre) {
        Artista art = buscarArtista(nombre);
        if (art != null) {
            artistas.remove(art);
            return true;
        }
        return false;
    }

    public String listarArtistas() {
        String salida = "";
        for (int i = 0; i < artistas.size(); i++) {
            salida += artistas.get(i).toString() + "\n";
        }
        return salida;
    }
    //---------------OBRAS-----------------
    public boolean agregarObra(Obra obra) {
        return gestionObras.agregarObra(obra);
    }

    public boolean eliminarObra(String titulo) {
        return gestionObras.eliminarObra(titulo);
    }

    public String listarObras() {
        return gestionObras.listarObras();
    }

    public Obra buscarObra(String titulo) {
        return gestionObras.buscarObra(titulo);
    }

    //----------------CLIENTES-----------------
    public boolean agregarCliente(Cliente cliente) {
        return controlCliente.agregarCliente(cliente);
    }

    public boolean eliminarCliente(String nombre) {
        return controlCliente.eliminarCliente(nombre);
    }

    public String listarClientes() {
        return controlCliente.listarClientes();
    }

    public Cliente buscarCliente(String nombre) {
        return controlCliente.buscarCliente(nombre);
    }

    //---------------COMPRAS-----------------

    //Busca una compra por nombre de cliente y titulo de obra
    public Compra buscarCompra(String nombre, String titulo) {
        for (int i = 0; i < compras.size(); i++) {
            if (compras.get(i).getCliente().getNombre().equalsIgnoreCase(nombre) && compras.get(i).getObra().getTitulo().equalsIgnoreCase(titulo)) {
                return compras.get(i);
            }
        }
        return null;
    }

    public boolean realizarCompra(Compra compra) {
        Compra c = buscarCompra(compra.getCliente().getNombre(), compra.getObra().getTitulo());
        if (c == null) {
            compras.add(compra);
            return true;
        }
        return false;
    }

    public boolean eliminarCompra(String nombre, String titulo) {
        Compra c = buscarCompra(nombre, titulo);
        if (c != null) {
            compras.remove(c);
            return true;
        }
        return false;
    }

    public String listarCompras() {
        String salida = "";
        for (int i = 0; i < compras.size(); i++) {
            salida += compras.get(i).toString() + "\n";
        }
        return salida;
    }


}
