package com.example;

import java.time.LocalDate;

public class Compra {
    private LocalDate fecha;
    private double precio;
    private Cliente cliente;
    private Obra obra;

    public Compra(double precio, Cliente cliente, Obra obra) {
        this.fecha = LocalDate.now();
        this.precio = precio;
        this.cliente = cliente;
        this.obra = obra;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    @Override
    public String toString() {
        return "Compra [fecha=" + fecha + ", precio=" + precio + ", cliente=" + cliente + ", obra=" + obra + "]";
    }

    

    

    
}
